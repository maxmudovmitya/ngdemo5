class Story{
  String? image;
  String? name;

  Story(this.image, this.name);
}