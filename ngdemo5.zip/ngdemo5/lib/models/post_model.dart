class Post{
  String? userImage;
  String? userName;
  String? postImage;
  String? caption;

  Post({this.userImage, this.userName, this.caption, this.postImage});

}
