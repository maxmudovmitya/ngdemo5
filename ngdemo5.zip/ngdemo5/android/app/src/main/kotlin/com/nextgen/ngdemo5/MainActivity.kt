package com.nextgen.ngdemo5

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
